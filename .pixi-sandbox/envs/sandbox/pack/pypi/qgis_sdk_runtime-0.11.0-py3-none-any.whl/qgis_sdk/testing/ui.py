"""Fakes for the UI contracts, and a way to build a surface without Qt.

``FakeUi`` is what a pure test hands a ``PluginContext`` as ``ui``: an action
that calls ``ctx.ui.open(BufferDialog, initial={...})`` is observed as
one :class:`OpenedSurface` record, and nothing is built - ``build()`` is the
author's Qt code and runs only under a host. Given the application, the fake
also refuses a surface it does not register, exactly as the Desktop does.

:func:`fake_ui_context` assembles the ``UiContext`` a surface sees, over
recording fakes; :func:`build_surface` runs a surface's ``build()`` under it
the way the host does, so a catalogue tree can be driven and snapshotted in
a pure test.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, Any


class _CcState:
    """A mutable record shared by the phases of one long function."""

    def __init__(_cc_self, **values):
        _cc_self.__dict__.update(values)


class _CcReturn:
    """An early return travelling out of a phase."""

    def __init__(_cc_self, value):
        _cc_self.value = value


def _cc_fake_ui_context_p1(_s):
    from qgis_sdk.ui.actions import ViewActions

    _s.ViewActions = ViewActions
    from qgis_sdk.ui.streams import ViewStreams

    _s.ViewStreams = ViewStreams

    from .fakes import RecordingLog, RecordingNotifications

    _s.RecordingLog = RecordingLog
    _s.RecordingNotifications = RecordingNotifications

    if _s.scope is None:
        _s.scope = ResourceScope()
    _s.notifications = _s.services.pop(
        "notifications", None
    ) or _s.RecordingNotifications(_s.scope)
    _s.view = _s.services.pop("view", None) or FakeViewControl()
    if "log" not in _s.services:
        _s.services["log"] = _s.RecordingLog(_s.scope)


def _cc_fake_ui_context_p2(_s):
    if _s.runtime is not None:
        if "actions" in _s.services or "streams" in _s.services:
            raise QgisSdkUiError(
                "fake_ui_context: pass runtime or actions/streams, not both"
            )
        _s.services["actions"] = _s.ViewActions(
            _s.runtime, view_id=_s.view_id, scope=_s.scope
        )
        _s.services["streams"] = _s.ViewStreams(_s.runtime, view_id=_s.view_id)
        if "jobs" not in _s.services:
            _s.context = getattr(_s.runtime, "context", None)
            if _s.context is not None and _s.context.has("jobs"):
                # The same view-scoped facade a real host builds, so a test
                # sees the owner rules instead of a plugin-lifetime stand-in.
                _s.services["jobs"] = _s.context.jobs.scoped(_s.scope)


def _cc_fake_ui_context_p3(_s):
    return _CcReturn(
        UiContext(_s.notifications, _s.view, _s.scope, UiServices(**_s.services))
    )


def _build_surface_tail1(**values):
    ctx = values["ctx"]
    initial = values["initial"]
    surface = values["surface"]
    instance = surface()
    materialise(instance)  # the declared components, as this window's copies
    instance.ctx = ctx
    instance.initial = MappingProxyType(dict(initial or {}))
    if surface.ui is not None and _uses_default_build(surface):
        # The Designer file as declared names, not widgets: ``@on`` wires to
        # fake signals a test emits.
        root: Any = fake_ui_tree(resolve_ui_path(surface, surface.ui))
    else:
        root = instance.build()
    if isinstance(root, Component) and not root.attached:
        root.attach(ctx)
    wire_surface(instance, root, ctx)
    return BuiltSurface(instance, root, ctx)


if TYPE_CHECKING:
    from qgis_sdk.core._application import QgisSdkPlugin

from qgis_sdk.core import ResourceScope, UiContext, UiServices
from qgis_sdk.models import QgisSdkUiError
from qgis_sdk.ui.components import Component
from qgis_sdk.ui.declarative import materialise
from qgis_sdk.ui.surfaces import Surface, describe_surface, is_surface_class
from qgis_sdk.ui.uifile import fake_ui_tree, resolve_ui_path
from qgis_sdk.ui.wiring import wire_surface

__all__ = [
    "BuiltSurface",
    "FakeUi",
    "FakeViewControl",
    "OpenedSurface",
    "build_surface",
    "fake_ui_context",
]


@dataclass(frozen=True, slots=True)
class OpenedSurface:
    """One ``ctx.ui.open`` call the fake recorded."""

    surface: type
    initial: Mapping[str, object]

    @property
    def id(self) -> str:
        return describe_surface(self.surface).id


class FakeUi:
    """Record ``open`` calls; refuse unregistered surfaces when a plugin is known."""

    def __init__(
        self, scope: ResourceScope, *, app: QgisSdkPlugin | None = None
    ) -> None:
        self._scope = scope
        self._app = app
        self._opened: list[OpenedSurface] = []

    @property
    def opened(self) -> tuple[OpenedSurface, ...]:
        """Every recorded opening, oldest first."""
        return tuple(self._opened)

    def open(
        self, surface: type, *, initial: Mapping[str, object] | None = None
    ) -> OpenedSurface:
        self._scope.ensure_open()
        if not is_surface_class(surface):
            name = getattr(surface, "__name__", repr(surface))
            raise QgisSdkUiError(f"{name} is not a Dialog/Dock subclass")
        if self._app is not None:
            from qgis_sdk.bindings import describe_bindings

            if all(
                bound.cls is not surface
                for bound in describe_bindings(self._app).surfaces
            ):
                raise QgisSdkUiError(
                    f"{surface.__name__} is not registered: use app.add_surface(...)"
                )
        record = OpenedSurface(surface, MappingProxyType(dict(initial or {})))
        self._opened.append(record)
        return record


@dataclass(slots=True)
class FakeViewControl:
    """Count close requests; the owning test decides what closing means."""

    close_requests: int = field(default=0)

    def request_close(self) -> None:
        self.close_requests += 1


def fake_ui_context(
    scope: ResourceScope | None = None,
    *,
    runtime: Any | None = None,
    view_id: str = "test",
    **services: Any,
) -> UiContext:
    """The ``UiContext`` a surface sees, over recording fakes.

    ``notifications`` (a ``RecordingNotifications``), ``view`` (a
    ``FakeViewControl``) and ``log`` (a ``RecordingLog``) are provided
    unless passed; ``layers``, ``project``, ``files``, ``settings``,
    ``network``, ``actions``, ``streams``, ``algorithms``, ``styles``,
    ``desktop`` and ``ui`` are carried when given. Shared service objects
    keep their own scopes; the caller controls their lifetimes.
    ``runtime`` - a started ``PluginRuntime`` - builds ``actions`` and
    ``streams`` as the host would, dispatches action calls on behalf of
    ``scope``, and adds ``jobs`` when the plugin declares any.
    """
    _s = _CcState(scope=scope, runtime=runtime, view_id=view_id, services=services)
    for _p in (_cc_fake_ui_context_p1, _cc_fake_ui_context_p2, _cc_fake_ui_context_p3):
        _r = _p(_s)
        if isinstance(_r, _CcReturn):
            return _r.value
    return None


@dataclass(slots=True)
class BuiltSurface:
    """A surface built under the fake: the instance, its root and its context."""

    surface: Any
    root: Any
    ctx: UiContext

    def find(self, name: str) -> Any:
        """The node called ``name`` anywhere in the tree: a component or a fake widget."""
        root = self.root
        if isinstance(root, Component):
            if root.name == name:
                return root
            finder = getattr(root, "find", None)
            if finder is None:
                raise QgisSdkUiError(f"{root.name!r} has no children to search")
            return finder(name)
        finder = getattr(root, "find", None)
        if callable(finder):
            return finder(name)
        raise QgisSdkUiError("build() returned no catalogue component")

    def close(self) -> None:
        """What closing the window does: ``on_close()``, then the scope."""
        on_close = getattr(self.surface, "on_close", None)
        try:
            if callable(on_close):
                on_close()
        finally:
            if not self.ctx.scope.closed:
                self.ctx.scope.close()


def build_surface(
    surface: type, ctx: UiContext, *, initial: Mapping[str, object] | None = None
) -> BuiltSurface:
    """Run ``surface.build()`` under ``ctx`` exactly as the host would, minus Qt.

    The instance gets ``ctx`` and ``initial`` first; a catalogue component
    ``build()`` returns is attached to the context, never mounted; the
    ``@on``/``@subscribe`` methods and the behaviour mixins are wired as the
    host would. A ``ui =`` surface gets a :class:`~qgis_sdk.ui.uifile.FakeUiTree`
    read from the Designer file. A surface in the widget form is refused: it
    *is* a Qt widget and opens only under a host.
    """
    if not is_surface_class(surface):
        name = getattr(surface, "__name__", repr(surface))
        raise QgisSdkUiError(f"{name} is not a Dialog/Dock subclass")
    if not issubclass(surface, Surface):
        raise QgisSdkUiError(
            f"{surface.__name__} is a widget surface; it needs Qt and a host to open"
        )
    return _build_surface_tail1(**{**globals(), **locals()})


def _uses_default_build(surface: type) -> bool:
    return surface.build is Surface.build
