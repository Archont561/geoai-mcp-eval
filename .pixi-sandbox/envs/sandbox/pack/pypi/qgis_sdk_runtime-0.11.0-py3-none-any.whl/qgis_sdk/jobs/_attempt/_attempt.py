"""The attempt: one run of a job on the step scheduler, progress and cancellation."""

from __future__ import annotations

import threading
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, TypedDict, Unpack

from qgis_sdk.core import ResourceScope, WorkerContext
from qgis_sdk.core.scheduling import Job, Yield
from qgis_sdk.declarations import QgisSdkDeclarationError, type_name
from qgis_sdk.jobs._authoring import (
    _EVENTS,
    _STATUS_OF_STATE,
    JobDescription,
    JobEvent,
    JobStatus,
    _accepts,
)
from qgis_sdk.jobs._subscriptions import JobFault, JobSubscription
from qgis_sdk.models import (
    QgisSdkJobCancelledError,
    QgisSdkJobNotSettledError,
    QgisSdkJobPrerequisiteError,
    QgisSdkScopeClosedError,
)
from qgis_sdk.services import WorkItem

from ._progress import Cancellation, Progress

if TYPE_CHECKING:
    from qgis_sdk.jobs._handles import JobHandle
    from qgis_sdk.jobs._service import JobService
    from qgis_sdk.jobs._service._init_state import Runtime

__all__ = ["run_attempt"]


class _CcState:
    """A mutable record shared by the phases of one long function."""

    def __init__(_cc_self, **values):
        _cc_self.__dict__.update(values)


class _CcReturn:
    """An early return travelling out of a phase."""

    def __init__(_cc_self, value):
        _cc_self.value = value


async def _cc_run_attempt_p1(_s):
    _s.attempt.scope.ensure_open()
    await _wait_for_prerequisites(_s.attempt)
    _s.workers = _s.attempt.runtime.workers
    assert _s.workers is not None, "submission is refused without a worker backend"
    _s.context = WorkerContext(
        progress=_s.attempt.progress,
        cancellation=Cancellation(_s.attempt),
    )


async def _cc_run_attempt_p2(_s):
    _s.item = WorkItem(
        title=_s.attempt.description.title,
        progress=_s.attempt.progress,
        cancel=_s.attempt.request_cancel,
    )
    _s.handoff = _s.workers.offload(
        lambda: _s.function(_s.context, **_s.arguments), item=_s.item
    )
    _s.outcome = await _s.handoff
    _s.description = _s.attempt.description


async def _cc_run_attempt_p3(_s):
    if not _accepts(_s.outcome, _s.description.result_type):
        raise QgisSdkDeclarationError(
            f"{_s.description.id}: returned {type_name(type(_s.outcome))}, not the "
            f"declared {type_name(_s.description.result_type)}"
        )
    return _CcReturn(_s.outcome)


class __AttemptMixin1:
    @property
    def owner_closed(self) -> bool:
        """Whether the owner is gone - told so, or found so after the attempt finished.

        A finished attempt leaves the service's books, so it is not told when
        its owner closes later; asking the scope keeps a late subscription on
        such a handle from replaying into a disposed view.
        """
        return self._owner_closed or self.owner._scope.closed

    @property
    def job(self) -> Job:
        job = self._job
        assert job is not None, "an attempt is submitted before it is handed out"
        return job

    @property
    def cancelled(self) -> bool:
        """Whether a cancellation was requested: by the owner or a quiesce.

        Read from a worker through ``ctx.cancellation.is_cancelled()``, so the
        first half is a :class:`threading.Event`; the scheduler's request
        covers a host quiescing for a replacement.
        """
        job = self._job
        return self._cancelled.is_set() or (
            job is not None and job.cancellation.is_cancelled()
        )

    @property
    def status(self) -> JobStatus:
        """The job's state, or ``CANCELLED`` when its host abandoned it.

        An abandoned request-scoped job has no scheduler state worth reading -
        the request is over and nothing will ever deliver a worker's report - so
        the attempt answers for it (decision-52).
        """
        if self._abandoned:
            return JobStatus.CANCELLED
        return _STATUS_OF_STATE[self.job.state]

    @property
    def error(self) -> BaseException | None:
        return self.job.error if self.status is JobStatus.FAILED else None

    def outcome(self) -> object:
        """Return the result, or raise what stands in its place."""
        status = self.status
        if status is JobStatus.SUCCEEDED:
            return self.job.result
        if status is JobStatus.CANCELLED:
            raise QgisSdkJobCancelledError(self.job.id)
        if status is JobStatus.FAILED:
            error = self.job.error
            assert error is not None, "a failed job records its error"
            raise error
        raise QgisSdkJobNotSettledError(self.id, status.value)

    # -- subscriptions

    def subscribe(
        self, event: JobEvent, callback: Callable, owner: ResourceScope | None
    ) -> JobSubscription:
        if self.owner_closed:
            raise QgisSdkScopeClosedError()
        if owner is not None:
            owner.ensure_open()
        # The job's own owner detaches everything on disposal; only a
        # different owner needs a hook of its own, held per scope so a
        # finished job leaves nothing behind on it.
        hooked = owner if owner is not None and owner is not self.owner._scope else None
        subscription = JobSubscription(self, event, callback, hooked)
        if self._replay(subscription):
            return subscription
        self._subscriptions[event][subscription] = None
        if hooked is not None:
            self.runtime.add_owner_hook(hooked, subscription)
        return subscription

    def _replay(self, subscription: JobSubscription) -> bool:
        """Deliver the current state once; return whether that completed it."""
        event = subscription.event
        status = self.status
        if event == "progress":
            latest = self.progress.latest
            if latest is not None:
                self._invoke(subscription, latest)
            if status.settled:
                subscription._active = False
                return True
            return False
        if not status.settled:
            return False
        if event == _TERMINAL_EVENT[status]:
            self._invoke(subscription, *self._terminal_payload())
        subscription._active = False
        return True

    def detach(self) -> None:
        """Dispose every subscription; nothing is delivered after this."""
        for registry in self._subscriptions.values():
            for subscription in tuple(registry):
                subscription.dispose()

    def _invoke(self, subscription: JobSubscription, *payload: object) -> None:
        try:
            subscription._callback(*payload)
        except Exception as error:  # noqa: BLE001 - a subscriber fault is reported
            subscription.dispose()
            self.runtime.fault(JobFault(self.id, subscription.event, error))

    def _emit(self, event: JobEvent, *payload: object) -> None:
        for subscription in tuple(self._subscriptions[event]):
            if subscription.active:
                self._invoke(subscription, *payload)

    def _terminal_payload(self) -> tuple[object, ...]:
        status = self.status
        if status is JobStatus.SUCCEEDED:
            return (self.job.result,)
        if status is JobStatus.FAILED:
            return (self.job.error,)
        return ()

    # -- delivery, on the tick

    def deliver(self) -> None:
        """Hand the subscribers what changed since the last tick."""
        fraction = self.progress.take()
        if fraction is not None and not self.owner_closed:
            self._emit("progress", fraction)
        status = self.status
        if not status.settled or self.delivered:
            return
        self.delivered = True
        if not self.owner_closed:
            self._emit(_TERMINAL_EVENT[status], *self._terminal_payload())
        self.finish()


class __AttemptMixin2:
    def finish(self) -> None:
        """Complete the attempt: no more callbacks, waiters wake, the scope closes."""
        self.detach()
        self.settled.set()
        self.runtime.attempts.pop(self.id, None)
        if not self.scope.closed:
            self.scope.close()

    # -- ownership

    def owner_disposed(self) -> None:
        """The owning view is gone: detach now, ask the job to stop, keep the attempt."""
        self._owner_closed = True
        self.detach()
        self.request_cancel()

    def request_cancel(self) -> None:
        """Ask the worker to stop; the attempt keeps the outcome until it reports."""
        self._cancelled.set()
        self.job.cancel()

    def abandoned(self) -> None:
        """The plugin is gone: the scheduler abandons the job; nobody is called."""
        self._owner_closed = True
        self.detach()
        self.settled.set()

    def cancelled_by_request(self) -> None:
        """The request is over: report this job cancelled and stop tracking it.

        Called when a request scope closes (decision-52). Unlike
        :meth:`abandoned` - which leaves the scheduler's own verdict in place
        when a whole plugin unloads - a request has no pump that could ever
        deliver a worker's report, so the attempt records the outcome itself:
        the handle reads ``CANCELLED`` at once, a worker still running is asked
        to stop, the job leaves the scheduler with any later report counted as
        dropped, and nothing is delivered to anyone.
        """
        self._abandoned = True
        self._owner_closed = True
        self.detach()
        self.request_cancel()
        self.runtime.scheduler.abandon(self.job)
        self.settled.set()
        self.runtime.attempts.pop(self.id, None)
        if not self.scope.closed:
            self.scope.close()


class _Attempt(__AttemptMixin1, __AttemptMixin2):
    """Everything the service tracks about one submitted job."""

    def __init__(self, **options: Unpack[_InitOptions1]) -> None:
        values = _InitValues1(**options)
        self.runtime = values.runtime
        self.owner = values.owner
        self.description = values.description
        self.id = values.logical_id
        self.prerequisites = values.prerequisites
        """Jobs this attempt runs after (``ctx.jobs.after``), submitted earlier."""
        self.attempt = 1
        self.scope = values.runtime.scope.child()
        self.progress = Progress()
        self._cancelled = threading.Event()
        self._job: Job | None = None
        self._subscriptions: dict[JobEvent, dict[JobSubscription, None]] = {
            event: {} for event in _EVENTS
        }
        self._owner_closed = False
        self._abandoned = False
        self.delivered = False
        self.settled = threading.Event()


_TICK_IN_PROGRESS = "a tick is already in progress on this thread"
_NOT_THE_DRIVING_THREAD = (
    "the tick and quiesce belong to the thread that built the service; a job "
    "body runs on a worker and has no tick of its own"
)

_TERMINAL_EVENT: dict[JobStatus, JobEvent] = {
    JobStatus.SUCCEEDED: "success",
    JobStatus.FAILED: "failure",
    JobStatus.CANCELLED: "cancelled",
}


async def _wait_for_prerequisites(attempt: _Attempt) -> None:
    """Hold the body until the jobs it declared it comes after have settled.

    A dependency is enforced here, before the body is handed to a worker, so a
    backend never sees work it must not start yet - one task, no sub-tasks, and
    no second scheduler inside the task manager. Waiting costs one ``Yield``
    per tick and nothing else: the job stays visible, cancellable and named as
    a blocker like any other. A prerequisite that did not succeed fails this
    attempt without running its body.
    """
    if not attempt.prerequisites:
        return
    while True:
        pending = [
            handle for handle in attempt.prerequisites if not handle.status.settled
        ]
        if not pending:
            break
        await Yield()
    for handle in attempt.prerequisites:
        status = handle.status
        if status is not JobStatus.SUCCEEDED:
            raise QgisSdkJobPrerequisiteError(attempt.id, handle.id, status)


async def run_attempt(
    attempt: _Attempt, function: Callable[..., Any], arguments: dict[str, Any]
) -> object:
    """Hand the whole body to a worker, wait for it here, check what came back.

    The coroutine itself only ever runs on the driving thread: it submits a
    callable and suspends on the worker's handoff, so the body is never
    executed by whoever called :meth:`JobService.tick`. The context built for
    that callable carries progress and cancellation and refuses everything
    else (decision-65); the result is validated here, on the driving thread,
    before any subscriber sees it.
    """
    _s = _CcState(attempt=attempt, function=function, arguments=arguments)
    for _p in (_cc_run_attempt_p1, _cc_run_attempt_p2, _cc_run_attempt_p3):
        _r = await _p(_s)
        if isinstance(_r, _CcReturn):
            return _r.value
    return None


class _InitOptions1(TypedDict, total=False):
    runtime: Runtime
    owner: JobService
    description: JobDescription
    logical_id: str
    prerequisites: tuple[JobHandle, ...]


@dataclass(frozen=True, slots=True)
class _InitValues1:
    runtime: Runtime
    owner: JobService
    description: JobDescription
    logical_id: str
    prerequisites: tuple[JobHandle, ...] = ()
