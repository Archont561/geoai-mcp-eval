"""PyQGIS-backed service adapters for the curated pure contracts.
from .context import NativeContextOptions, native_plugin_context
from .context import NativeContextOptions, native_plugin_context

Importing a *name* from this package imports the adapter behind it and needs a
QGIS installation; importing the package itself does not. That split matters for
the hosts that never need the rest of the surface: a QGIS Server process serves
requests through :class:`~qgis_sdk.adapters.qgis.server.QgsServerHost` and has no
use for Qt Widgets or Processing, and the server wiring is checked against
``qgis.server`` stand-ins on a machine with no QGIS at all (TASK-80). The eager
form dragged every adapter in through ``.algorithms`` and made both impossible.

The adapters in this package implement the same ``qgis_sdk.services`` contracts
as the in-memory doubles, and the contract suite in ``tests/services`` runs both
against one set of tests.
"""

from __future__ import annotations

from importlib import import_module as _import_module
from typing import TYPE_CHECKING
from typing import Any as _Any

if TYPE_CHECKING:  # the names, for readers and type checkers; not imported
    from .algorithms import AlgorithmWiring, NativeAlgorithms
    from .canvas import NativeCanvas
    from .connections import NativeConnections
    from .context import IfaceDesktopAccess, NativeContextOptions, native_plugin_context
    from .features import NativeFeatureEditing, NativeFeatures
    from .jobs import DEFAULT_INTERVAL_MS, QgsJobPump
    from .layers import NativeLayers
    from .layouts import NativeLayouts
    from .log import NativeLog
    from .network import NativeNetworkTransport
    from .notifications import NativeNotifications
    from .processing import (
        NativeProcessing,
        NativeProcessingProvider,
        ProcessingServices,
    )
    from .project import NativeProject
    from .rasters import NativeRasters
    from .server import QgsServerHost
    from .settings import NativeSettings
    from .styles import NativeStyles
    from .tasks import QgsTaskWorkers
    from .workers import ThreadPoolWorkers

__all__ = [
    "DEFAULT_INTERVAL_MS",
    "AlgorithmWiring",
    "IfaceDesktopAccess",
    "NativeAlgorithms",
    "NativeCanvas",
    "NativeConnections",
    "NativeContextOptions",
    "NativeFeatureEditing",
    "NativeFeatures",
    "NativeLayers",
    "NativeLayouts",
    "NativeLog",
    "NativeNetworkTransport",
    "NativeNotifications",
    "NativeProcessing",
    "NativeProcessingProvider",
    "NativeProject",
    "NativeRasters",
    "NativeSettings",
    "NativeStyles",
    "ProcessingServices",
    "QgsJobPump",
    "QgsServerHost",
    "QgsTaskWorkers",
    "ThreadPoolWorkers",
    "native_plugin_context",
]

#: Which module holds each exported name; the import happens on first access.
_EXPORTS: dict[str, str] = {
    "AlgorithmWiring": ".algorithms",
    "DEFAULT_INTERVAL_MS": ".jobs",
    "IfaceDesktopAccess": ".context",
    "NativeAlgorithms": ".algorithms",
    "NativeCanvas": ".canvas",
    "NativeConnections": ".connections",
    "NativeFeatureEditing": ".features",
    "NativeFeatures": ".features",
    "NativeLayers": ".layers",
    "NativeLayouts": ".layouts",
    "NativeLog": ".log",
    "NativeNetworkTransport": ".network",
    "NativeNotifications": ".notifications",
    "NativeProcessing": ".processing",
    "NativeProcessingProvider": ".processing",
    "ProcessingServices": ".processing",
    "NativeProject": ".project",
    "NativeRasters": ".rasters",
    "NativeSettings": ".settings",
    "NativeStyles": ".styles",
    "QgsJobPump": ".jobs",
    "QgsServerHost": ".server",
    "QgsTaskWorkers": ".tasks",
    "ThreadPoolWorkers": ".workers",
    "NativeContextOptions": ".context",
    "native_plugin_context": ".context",
}


def __getattr__(name: str) -> _Any:
    """Import the adapter behind ``name`` the first time it is asked for."""
    module_name = _EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = getattr(_import_module(module_name, __name__), name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(__all__)
