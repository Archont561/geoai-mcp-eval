"""Module for reading and writing schema objects."""

from __future__ import annotations

import datetime
import enum
import json
import re
import warnings
from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, Union

import pandas as pd

import pandera.errors
from pandera import dtypes
from pandera.api.checks import Check
from pandera.api.pandas.components import Column
from pandera.api.pandas.container import DataFrameSchema
from pandera.engines import pandas_engine
from pandera.io import common_io
from pandera.io._check_io import checks_dict_to_list
from pandera.io._constants import DATETIME_FORMAT, MISSING_PYYAML_MESSAGE
from pandera.io._flat_checks import (
    apply_flat_checks_to_dataframe_serialized,
    unflatten_component_checks_dict,
)
from pandera.io._minimal import apply_minimal_dataframe_container
from pandera.schema_statistics.common import deserialize_group_keys
from pandera.schema_statistics.pandas import get_dataframe_schema_statistics

if TYPE_CHECKING:
    from frictionless import Schema as FrictionlessSchema
_MISSING_FRICTIONLESS_IMPORT_ERROR_MESSAGE = (
    "Frictionless schema parsing requires 'frictionless' to be installed. "
    "Please install 'frictionless' to use this feature."
)

_DATETIME_COMPARISON_CHECKS = frozenset(
    {
        "equal_to",
        "not_equal_to",
        "greater_than",
        "greater_than_or_equal_to",
        "less_than",
        "less_than_or_equal_to",
        "in_range",
    }
)


def _serialize_check_stats(check_stats, dtype=None):
    """Serialize check statistics into json/yaml-compatible format."""

    def handle_stat_dtype(stat):
        # Handle enum types by converting them to a list of values
        if isinstance(stat, type) and issubclass(stat, enum.Enum):
            return [e.value for e in stat]

        # sets (e.g. the ``unique_values_eq`` statistic) are not json/yaml
        # serializable, so store them as a list, sorted when possible to
        # keep the output deterministic.
        if isinstance(stat, (set, frozenset)):
            try:
                return sorted(stat)
            except TypeError:
                return list(stat)

        # Custom checks may have string statistics resembling timestamps, so
        # preserve their legacy encoding and decoding behavior.
        if (
            check_options.get("check_name") in _DATETIME_COMPARISON_CHECKS
            and isinstance(dtype, pandas_engine.DateTime)
            and isinstance(stat, datetime.datetime)
        ):
            return stat.isoformat(sep=" ")

        if pandas_engine.Engine.dtype(dtypes.DateTime).check(
            dtype
        ) and hasattr(stat, "strftime"):
            # try serializing stat as a string if it's datetime-like,
            # otherwise return original value
            return stat.strftime(DATETIME_FORMAT)
        elif pandas_engine.Engine.dtype(dtypes.Timedelta).check(dtype):
            # try serializing stat into an int in nanoseconds if it's
            # timedelta-like, otherwise return original value
            return getattr(stat, "value", stat)

        return stat

    # Extract check options if they exist
    check_options = (
        check_stats.pop("options", {}) if isinstance(check_stats, dict) else {}
    )

    # Single-statistic dict: preserve the argument name (e.g. min_value, stat)
    # instead of coercing to "value", which breaks registered checks whose
    # statistic is not a unary positional alias.
    if isinstance(check_stats, dict) and len(check_stats) == 1:
        arg_name, arg_val = next(iter(check_stats.items()))
        coerced = handle_stat_dtype(arg_val)
        if check_options:
            return {arg_name: coerced, "options": check_options}
        return coerced

    # Handle dictionary case
    if isinstance(check_stats, dict):
        serialized_check_stats = {}
        for arg, stat in check_stats.items():
            serialized_check_stats[arg] = handle_stat_dtype(stat)
        if check_options:
            serialized_check_stats["options"] = check_options
        return serialized_check_stats

    return handle_stat_dtype(check_stats)


def _serialize_dataframe_stats(dataframe_checks):
    """
    Serialize global dataframe check statistics into json/yaml-compatible
    format.
    """
    serialized_checks = []

    for check_stats in dataframe_checks:
        # The case that `check_name` is not registered is handled in
        # `parse_checks` so we know that `check_name` exists.

        # infer dtype of statistics and serialize them
        serialized_check_stats = _serialize_check_stats(check_stats)
        serialized_checks.append(serialized_check_stats)

    return serialized_checks


def _serialize_component_stats(component_stats):
    """
    Serialize column or index statistics into json/yaml-compatible format.
    """
    serialized_checks = None
    if component_stats["checks"] is not None:
        serialized_checks = []
        for check_stats in component_stats["checks"]:
            serialized_check_stats = _serialize_check_stats(
                check_stats, component_stats["dtype"]
            )
            serialized_checks.append(serialized_check_stats)

    dtype = component_stats.get("dtype")
    if dtype:
        dtype = str(dtype)

    description = component_stats.get("description")
    title = component_stats.get("title")

    return {
        "title": title,
        "description": description,
        "dtype": dtype,
        "nullable": component_stats["nullable"],
        "checks": serialized_checks,
        **{
            key: component_stats.get(key)
            for key in [
                "name",
                "unique",
                "coerce",
                "required",
                "regex",
                "default",
                "report_duplicates",
                "drop_invalid_rows",
            ]
            if key in component_stats
            and (key != "default" or component_stats[key] is not None)
        },
    }


_MULTIINDEX_OPTION_KEYS = ("coerce", "strict", "name", "ordered", "unique")


def _serialize_multiindex_options(index):
    """Serialize the options of a ``MultiIndex`` schema component.

    The per-level ``Index`` components are serialized separately under the
    ``index`` key; this captures the options that belong to the
    ``MultiIndex`` itself. Returns ``None`` for a single ``Index`` or when
    the schema has no index.
    """
    if index is None or not hasattr(index, "indexes"):
        return None
    return {key: getattr(index, key) for key in _MULTIINDEX_OPTION_KEYS}


def _serialize_column_name(col_name):
    """Serialize column names that are not valid JSON object keys."""
    if isinstance(col_name, tuple):
        return list(col_name)
    return col_name


def _deserialize_column_name(col_name):
    """Deserialize column names from json-compatible representation."""
    if isinstance(col_name, list):
        return tuple(_deserialize_column_name(item) for item in col_name)
    return col_name


_DATAFRAME_LIBRARY_CHOICES = frozenset(
    ("pandas", "modin", "dask", "pyspark.pandas")
)


def serialize_schema(
    dataframe_schema,
    dataframe_library: str | None = None,
    *,
    minimal: bool = True,
):
    """Serialize dataframe schema into json/yaml-compatible format.

    :param dataframe_schema: pandas API :class:`~pandera.api.pandas.container.DataFrameSchema`.
    :param dataframe_library: Target dataframe implementation for metadata
        (``pandas``, ``modin``, ``dask``, or ``pyspark.pandas``). Defaults to
        ``pandas``.
    :param minimal: If True (default), omit keys equal to schema constructor
        defaults so output only contains user-meaningful options.

    The output includes an ``api`` field recording the underlying dataframe
    API (``dataframe_library``).
    """
    from pandera import __version__

    lib = dataframe_library or "pandas"
    if lib not in _DATAFRAME_LIBRARY_CHOICES:
        raise ValueError(
            "dataframe_library must be one of "
            f"{sorted(_DATAFRAME_LIBRARY_CHOICES)}, got {lib!r}"
        )

    statistics = get_dataframe_schema_statistics(dataframe_schema)

    columns, index, checks = None, None, None
    if statistics["columns"] is not None:
        columns = statistics["columns"]
        if all(isinstance(col_name, str) for col_name in columns):
            columns = {
                col_name: _serialize_component_stats(column_stats)
                for col_name, column_stats in columns.items()
            }
        else:
            serialized_columns = []
            for col_name, column_stats in columns.items():
                serialized_column = _serialize_component_stats(column_stats)
                serialized_column["name"] = _serialize_column_name(col_name)
                serialized_columns.append(serialized_column)
            columns = serialized_columns

    if statistics["index"] is not None:
        index = [
            _serialize_component_stats(index_stats)
            for index_stats in statistics["index"]
        ]

    if statistics["checks"] is not None:
        checks = _serialize_dataframe_stats(statistics["checks"])

    multiindex = _serialize_multiindex_options(dataframe_schema.index)

    out = {
        "schema_type": "dataframe",
        "version": __version__,
        "api": lib,
        "columns": columns,
        "checks": checks,
        "index": index,
        **({} if multiindex is None else {"multiindex": multiindex}),
        "dtype": dataframe_schema.dtype,
        "coerce": dataframe_schema.coerce,
        "strict": dataframe_schema.strict,
        "name": dataframe_schema.name,
        "ordered": dataframe_schema.ordered,
        "unique": dataframe_schema.unique,
        "report_duplicates": dataframe_schema.report_duplicates,
        "unique_column_names": dataframe_schema.unique_column_names,
        "add_missing_columns": dataframe_schema.add_missing_columns,
        "title": dataframe_schema.title,
        "description": dataframe_schema.description,
        "drop_invalid_rows": dataframe_schema.drop_invalid_rows,
    }
    if lib != "pandas":
        out["dataframe_library"] = lib
    if minimal:
        apply_minimal_dataframe_container(out, dataframe_schema)
    apply_flat_checks_to_dataframe_serialized(out)
    return out


def _deserialize_check_stats(check, serialized_check_stats, dtype=None):
    """Deserialize check statistics and reconstruct check with options."""

    def handle_stat_dtype(stat):
        try:
            if (
                options.get("check_name") in _DATETIME_COMPARISON_CHECKS
                and isinstance(dtype, pandas_engine.DateTime)
                and isinstance(stat, str)
            ):
                try:
                    return pd.to_datetime(stat, format="ISO8601")
                except (TypeError, ValueError):
                    pass
            if pandas_engine.Engine.dtype(dtypes.DateTime).check(dtype):
                return pd.to_datetime(stat, format=DATETIME_FORMAT)
            elif pandas_engine.Engine.dtype(dtypes.Timedelta).check(dtype):
                # serialize to int in nanoseconds
                return pd.to_timedelta(stat, unit="ns")
        except (TypeError, ValueError):
            return stat
        return stat

    # Extract options if they exist
    options = {}
    if isinstance(serialized_check_stats, dict):
        # handle case where serialized check stats are in the form of a
        # dictionary mapping Check arg names to values.
        options = serialized_check_stats.pop("options", {})
        # Handle special case for unary checks with options
        if (
            "value" in serialized_check_stats
            and len(serialized_check_stats) == 1
        ):
            serialized_check_stats = serialized_check_stats["value"]

    # Create check with original logic
    if isinstance(serialized_check_stats, dict):
        check_stats = {}
        for arg, stat in serialized_check_stats.items():
            if arg == "groups":
                check_stats[arg] = deserialize_group_keys(stat)
                continue
            check_stats[arg] = handle_stat_dtype(stat)
        check_instance = check(**check_stats)
    else:
        # otherwise assume unary check function signature
        check_instance = check(handle_stat_dtype(serialized_check_stats))

    # Apply options if they exist
    if options:
        for option_name, option_value in options.items():
            if option_name == "check_name":
                continue
            if option_name == "groups":
                option_value = deserialize_group_keys(option_value)
            setattr(check_instance, option_name, option_value)

    return check_instance


_DECIMAL_DTYPE_PATTERN = re.compile(
    r"Decimal\(\s*(\d+)\s*,\s*(\d+)\s*\)", re.IGNORECASE
)


def _deserialize_dtype(serialized_dtype):
    """Deserialize a dtype, supporting the string representation of
    parametrized dtypes that the engine doesn't recognize as aliases,
    e.g. ``"Decimal(28, 0)"``. GH#1165

    Parametrized dtype strings are handled before falling back to
    :meth:`Engine.dtype`, since the exception raised for unrecognized
    strings varies across numpy/pandas versions (e.g. numpy raises
    ``ValueError`` for strings containing commas).
    """
    if isinstance(serialized_dtype, str):
        match = _DECIMAL_DTYPE_PATTERN.fullmatch(serialized_dtype)
        if match:
            return pandas_engine.Decimal(
                precision=int(match.group(1)), scale=int(match.group(2))
            )
    return pandas_engine.Engine.dtype(serialized_dtype)


def _deserialize_component_stats(serialized_component_stats):
    serialized_component_stats = dict(serialized_component_stats)
    unflatten_component_checks_dict(serialized_component_stats)

    dtype = serialized_component_stats.get("dtype")
    if dtype:
        dtype = _deserialize_dtype(dtype)

    description = serialized_component_stats.get("description")
    title = serialized_component_stats.get("title")

    checks = checks_dict_to_list(serialized_component_stats.get("checks"))
    if checks is not None:
        checks = [
            _deserialize_check_stats(
                getattr(Check, check["options"]["check_name"]), check, dtype
            )
            for check in checks
        ]
    return {
        "title": title,
        "description": description,
        "dtype": dtype,
        "checks": checks,
        **{
            key: serialized_component_stats.get(key)
            for key in [
                "name",
                "nullable",
                "unique",
                "coerce",
                "required",
                "regex",
                "default",
                "report_duplicates",
                "drop_invalid_rows",
            ]
            if key in serialized_component_stats
        },
    }


def deserialize_schema(serialized_schema):
    """
    De-serialize the schema from a JSON-able mapping.

    :param serialized_schema: a mapping representing the schema
    :returns:
        the schema de-serialized into :class:`~pandera.api.pandas.container.DataFrameSchema`
    """

    from pandera.pandas import Index, MultiIndex

    # GH#475
    serialized_schema = serialized_schema if serialized_schema else {}

    if not isinstance(serialized_schema, Mapping):
        raise pandera.errors.SchemaDefinitionError(
            "Schema representation must be a mapping."
        )

    columns = serialized_schema.get("columns")
    index = serialized_schema.get("index")
    checks = checks_dict_to_list(serialized_schema.get("checks"))

    if columns is not None:
        if isinstance(columns, list):
            deserialized_columns = {}
            for column_stats in columns:
                col_name = _deserialize_column_name(column_stats.get("name"))
                component_stats = {
                    key: value
                    for key, value in column_stats.items()
                    if key != "name"
                }
                deserialized_columns[col_name] = Column(
                    **_deserialize_component_stats(component_stats)
                )
            columns = deserialized_columns
        else:
            columns = {
                col_name: Column(**_deserialize_component_stats(column_stats))
                for col_name, column_stats in columns.items()
            }

    if index is not None:
        index = [
            _deserialize_component_stats(index_component)
            for index_component in index
        ]

    if checks is not None:
        # handles unregistered checks by raising AttributeErrors from getattr
        checks = [
            _deserialize_check_stats(
                getattr(Check, check["options"]["check_name"]), check
            )
            for check in checks
        ]

    if index is None:
        pass
    elif len(index) == 1 and not isinstance(
        serialized_schema.get("multiindex"), dict
    ):
        index = Index(**index[0])
    else:
        index = MultiIndex(
            indexes=[Index(**index_properties) for index_properties in index],
            **(serialized_schema.get("multiindex") or {}),
        )

    metadata = None
    if serialized_schema.get("metadata"):
        metadata = dict(serialized_schema["metadata"])
    # ``dataframe_library`` (legacy) and ``api`` (newer schema files) both
    # tag the pandas-API dataframe implementation. Both are optional and
    # default to pandas when absent; the default adds no metadata so that
    # round-tripped schemas stay equal to their originals.
    lib = serialized_schema.get("dataframe_library")
    if lib is None:
        lib = serialized_schema.get("api", "pandas")
    if lib in _DATAFRAME_LIBRARY_CHOICES and lib != "pandas":
        if metadata is None:
            metadata = {}
        metadata["dataframe_library"] = lib

    return DataFrameSchema(
        columns=columns,
        checks=checks,
        index=index,
        dtype=serialized_schema.get("dtype", None),
        coerce=serialized_schema.get("coerce", False),
        strict=serialized_schema.get("strict", False),
        name=serialized_schema.get("name", None),
        ordered=serialized_schema.get("ordered", False),
        unique=serialized_schema.get("unique", None),
        report_duplicates=serialized_schema.get("report_duplicates", "all"),
        unique_column_names=serialized_schema.get(
            "unique_column_names", False
        ),
        add_missing_columns=serialized_schema.get(
            "add_missing_columns", False
        ),
        title=serialized_schema.get("title", None),
        description=serialized_schema.get("description", None),
        metadata=metadata,
        drop_invalid_rows=serialized_schema.get("drop_invalid_rows", False),
    )


def from_yaml(yaml_schema):
    """Create :class:`~pandera.api.pandas.container.DataFrameSchema` from yaml file.

    :param yaml_schema: str or Path to yaml schema, or serialized yaml string.
    :returns: dataframe schema.
    """
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover
        raise ImportError(MISSING_PYYAML_MESSAGE) from exc

    try:
        with Path(yaml_schema).open("r", encoding="utf-8") as f:
            serialized_schema = yaml.safe_load(f)
    except (TypeError, OSError):
        serialized_schema = yaml.safe_load(yaml_schema)
    return deserialize_schema(serialized_schema)


def to_yaml(
    dataframe_schema,
    stream=None,
    dataframe_library=None,
    *,
    minimal: bool = True,
):
    """Write :class:`~pandera.api.pandas.container.DataFrameSchema` to yaml file.

    :param dataframe_schema: schema to write to file or dump to string.
    :param stream: file stream to write to. If None, dumps to string.
    :param dataframe_library: optional ``dataframe_library`` tag; see
        :func:`serialize_schema`.
    :param minimal: passed to :func:`serialize_schema`.
    :returns: yaml string if stream is None, otherwise returns None.
    """
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover
        raise ImportError(MISSING_PYYAML_MESSAGE) from exc

    statistics = serialize_schema(
        dataframe_schema,
        dataframe_library=dataframe_library,
        minimal=minimal,
    )

    def _write_yaml(obj, stream):
        return yaml.safe_dump(obj, stream=stream, sort_keys=False)

    try:
        with Path(stream).open("w", encoding="utf-8") as f:
            _write_yaml(statistics, f)
    except (TypeError, OSError):
        return _write_yaml(statistics, stream)


def from_json(source):
    """
    Create :class:`~pandera.api.pandas.container.DataFrameSchema` from json file.

    :param source:
        Depending on the type, source is assumed to be:

        1) str or Path to a file containing json schema (if the file exists),
        2) str as a JSON-encoded schema, or
        3) stream that we can read from containing the schema as JSON-encoded
           string.

    :returns: dataframe schema.
    """
    if isinstance(source, str):
        try:
            serialized_schema = json.loads(source)
        except json.decoder.JSONDecodeError:
            with Path(source).open(encoding="utf-8") as f:
                serialized_schema = json.load(fp=f)
    elif isinstance(source, Path):
        with source.open(encoding="utf-8") as f:
            serialized_schema = json.load(fp=f)
    else:
        serialized_schema = json.load(fp=source)

    return deserialize_schema(serialized_schema)


def to_json(
    dataframe_schema,
    target=None,
    dataframe_library=None,
    *,
    minimal: bool = True,
    **kwargs,
):
    """
    Write :class:`~pandera.api.pandas.container.DataFrameSchema` to json file.

    :param dataframe_schema: schema to write to file or dump to string.
    :param target: file path or stream to write to. If None, returns a
        dump to string.
    :param dataframe_library: optional ``dataframe_library`` tag; see
        :func:`serialize_schema`.
    :param minimal: passed to :func:`serialize_schema`.
    :param kwargs: keyword arguments to pass into :func:`json.dump`
    :returns: json string if stream is None, otherwise returns None.
    """
    serialized_schema = serialize_schema(
        dataframe_schema,
        dataframe_library=dataframe_library,
        minimal=minimal,
    )

    if target is None:
        return json.dumps(serialized_schema, sort_keys=False, **kwargs)

    if isinstance(target, (str, Path)):
        with Path(target).open("w", encoding="utf-8") as f:
            json.dump(serialized_schema, fp=f, sort_keys=False, **kwargs)
    else:
        json.dump(serialized_schema, fp=target, sort_keys=False, **kwargs)


def to_script(
    dataframe_schema,
    path_or_buf=None,
    *,
    minimal: bool = True,
    script_type: Literal["schema", "model"] = "schema",
):
    """Write a pandas-API schema or model to a Python script.

    :param dataframe_schema: schema to write to file or dump to string.
    :param path_or_buf: filepath or buf stream to write to. If None, outputs
        string representation of the script.
    :param minimal: If True (default), omit constructor-default kwargs in the
        generated ``Column`` / ``DataFrameSchema`` / ``Field`` calls.
    :param script_type: ``\"schema\"`` emits ``DataFrameSchema`` (default).
        ``\"model\"`` emits a :class:`~pandera.api.dataframe.model.DataFrameModel`
        subclass for the pandas API.
    :returns: script string if ``path_or_buf`` is None, otherwise None.
    """
    return common_io.to_script(
        dataframe_schema,
        path_or_buf,
        minimal=minimal,
        script_type=script_type,
        backend="pandas",
    )


class FrictionlessFieldParser:
    """Parses frictionless data schema field specifications so we can convert
    them to an equivalent Pandera :class:`~pandera.api.pandas.components.Column`
    schema.

    For this implementation, we are using field names, constraints and types
    but leaving other frictionless parameters out (e.g. foreign keys, type
    formats).

    :param field: a field object from a frictionless schema.
    :param primary_keys: the primary keys from a frictionless schema. These
        are used to ensure primary key fields are treated properly - no
        duplicates, no missing values etc.
    """

    def __init__(self, field, primary_keys) -> None:
        self.constraints = field.constraints or {}
        self.primary_keys = primary_keys
        self.description = (
            None if field.description == "" else field.description
        )
        self.title = None if field.title == "" else field.title
        self.name = field.name
        self.type = field.type

    @property
    def dtype(self) -> str:
        """Determine what type of field this is, so we can feed that into
        :class:`~pandera.dtypes.DataType`. If no type is specified in the
        frictionless schema, we default to string values.

        :returns: the pandas-compatible representation of this field type as a
            string.
        """
        types = {
            "string": "string",
            "number": "float",
            "integer": "int",
            "boolean": "bool",
            "object": "object",
            "array": "object",
            "date": "string",
            "time": "string",
            "datetime": "datetime64[ns]",
            "year": "int",
            "yearmonth": "string",
            "duration": "timedelta64[ns]",
            "geopoint": "object",
            "geojson": "object",
            "any": "string",
        }
        return (
            "category"
            if self.constraints.get("enum", None)
            else types[self.type]
        )

    @property
    def checks(self) -> list[dict[str, Any]] | None:
        """Convert a set of frictionless schema field constraints into checks.

        This parses the standard set of frictionless constraints which can be
        found
        `here <https://specs.frictionlessdata.io/table-schema/#constraints>`_
        and maps them into the equivalent pandera checks.

        :returns: a dictionary of pandera :class:`~pandera.api.checks.Check`
            objects which capture the standard constraint logic of a
            frictionless schema field.
        """
        if not self.constraints:
            return None
        constraints = self.constraints.copy()
        checks = []

        def _combine_constraints(check_name, min_constraint, max_constraint):
            """Catches bounded constraints where we need to combine a min and max
            pair of constraints into a single check."""
            if min_constraint in constraints and max_constraint in constraints:
                checks.append(
                    {
                        "min_value": constraints.pop(min_constraint),
                        "max_value": constraints.pop(max_constraint),
                        "options": {"check_name": check_name},
                    }
                )

        _combine_constraints("in_range", "minimum", "maximum")
        _combine_constraints("str_length", "minLength", "maxLength")

        for constraint_type, constraint_value in constraints.items():
            base_stats = None
            check_name = None
            if constraint_type == "maximum":
                check_name = "less_than_or_equal_to"
                base_stats = {
                    "value": constraint_value,
                }
            elif constraint_type == "minimum":
                check_name = "greater_than_or_equal_to"
                base_stats = {
                    "value": constraint_value,
                }
            elif constraint_type == "maxLength":
                check_name = "str_length"
                base_stats = {
                    "min_value": None,
                    "max_value": constraint_value,
                }
            elif constraint_type == "minLength":
                check_name = "str_length"
                base_stats = {
                    "min_value": constraint_value,
                    "max_value": None,
                }
            elif constraint_type == "pattern":
                check_name = "str_matches"
                base_stats = {
                    "value": rf"^{constraint_value}$",
                }
            elif constraint_type == "enum":
                check_name = "isin"
                base_stats = {
                    "value": constraint_value,
                }

            if base_stats and check_name:
                base_stats["options"] = {"check_name": check_name}
                checks.append(base_stats)

        return checks or None

    @property
    def nullable(self) -> bool:
        """Determine whether this field can contain missing values.

        If a field is a primary key, this will return ``False``."""
        if self.name in self.primary_keys:
            return False
        return not self.constraints.get("required", False)

    @property
    def unique(self) -> bool:
        """Determine whether this field can contain duplicate values.

        If a field is a primary key, this will return ``True``.
        """

        # only set column-level uniqueness property if `primary_keys` contains
        # more than one field name.
        if len(self.primary_keys) == 1 and self.name in self.primary_keys:
            return True
        return self.constraints.get("unique", False)

    @property
    def coerce(self) -> bool:
        """Determine whether values within this field should be coerced.

        This currently returns ``True`` for all fields within a frictionless
        schema.
        """
        return True

    @property
    def required(self) -> bool:
        """Determine whether this field must exist within the data.

        This currently returns ``True`` for all fields within a frictionless
        schema.
        """
        return True

    @property
    def regex(self) -> bool:
        """Determine whether this field name should be used for regex matches.

        This currently returns ``False`` for all fields within a frictionless
        schema.
        """
        return False

    def to_pandera_column(self) -> dict:
        """Export this field to a column spec dictionary."""
        return {
            "checks": self.checks,
            "coerce": self.coerce,
            "nullable": self.nullable,
            "unique": self.unique,
            "dtype": self.dtype,
            "required": self.required,
            "name": self.name,
            "regex": self.regex,
            "description": self.description,
            "title": self.title,
        }


def from_frictionless_schema(
    schema: Union[str, Path, dict, FrictionlessSchema],
) -> DataFrameSchema:
    r"""Create a :class:`~pandera.api.pandas.container.DataFrameSchema` from either a
    frictionless json/yaml schema file saved on disk, or from a frictionless
    schema already loaded into memory.

    Each field from the frictionless schema will be converted to a pandera
    column specification using :class:`~pandera.io.pandas_io.FrictionlessFieldParser`
    to map field characteristics to pandera column specifications.

    :param schema: the frictionless schema object (or a
        string/Path to the location on disk of a schema specification) to
        parse.
    :returns: dataframe schema with frictionless field specs converted to
        pandera column checks and constraints for use as normal.
    :rtype: :class:`~pandera.api.pandas.container.DataFrameSchema`

    :example:

    Here, we're defining a very basic frictionless schema in memory before
    parsing it and then querying the resulting
    :class:`~pandera.api.pandas.container.DataFrameSchema` object as per any other Pandera
    schema:

    .. doctest::
        :skipif: SKIP_FRICTIONLESS_TESTS

        >>> from pandera.io.pandas_io import from_frictionless_schema
        >>>
        >>> FRICTIONLESS_SCHEMA = {
        ...     "fields": [
        ...         {
        ...             "name": "column_1",
        ...             "type": "integer",
        ...             "constraints": {"minimum": 10, "maximum": 99}
        ...         },
        ...         {
        ...             "name": "column_2",
        ...             "type": "string",
        ...             "constraints": {"maxLength": 10, "pattern": "\\S+"}
        ...         },
        ...     ],
        ...     "primaryKey": "column_1"
        ... }
        >>> schema = from_frictionless_schema(FRICTIONLESS_SCHEMA)
        >>> schema.columns["column_1"].checks
        [<Check in_range: in_range(10, 99)>]
        >>> schema.columns["column_1"].required
        True
        >>> schema.columns["column_1"].unique
        True
        >>> schema.columns["column_2"].checks
        [<Check str_length: str_length(None, 10)>, <Check str_matches: str_matches('^\S+$')>]
    """
    try:
        from frictionless import Schema as FrictionlessSchema
    except ImportError as exc:  # pragma: no cover
        raise ImportError(_MISSING_FRICTIONLESS_IMPORT_ERROR_MESSAGE) from exc

    if not isinstance(schema, FrictionlessSchema):
        schema = FrictionlessSchema(schema)

    assembled_schema = {
        "columns": {
            field.name: FrictionlessFieldParser(
                field, schema.primary_key
            ).to_pandera_column()
            for field in schema.fields
        },
        "index": None,
        "checks": None,
        "coerce": True,
        "strict": True,
        # only set dataframe-level uniqueness if the frictionless primary
        # key property specifies more than one field
        "unique": (
            None if len(schema.primary_key) == 1 else list(schema.primary_key)
        ),
    }
    return deserialize_schema(assembled_schema)
