"""TensorDict parsing, validation, and error-reporting backends."""

import copy
from collections import defaultdict
from typing import Any

from pandera import errors
from pandera.api.base.error_handler import ErrorHandler, get_error_category
from pandera.backends.base import BaseSchemaBackend, CoreCheckResult
from pandera.errors import SchemaError, SchemaErrorReason

try:
    import torch
except ImportError:
    torch = None


def _is_tensordict(obj: Any) -> bool:
    """Check if object is a TensorDict (any TensorDictBase subclass, e.g.
    LazyStackedTensorDict) or a tensorclass instance."""
    if torch is None:
        return False
    try:
        from tensordict import is_tensor_collection

        return is_tensor_collection(obj)
    except ImportError:
        return False


def _get_tensor(obj: Any, key: str) -> Any:
    """Get tensor from TensorDict or tensorclass object."""
    # For TensorDict, use __getitem__
    try:
        return obj[key]
    except (KeyError, TypeError, ValueError):
        pass

    # For tensorclass, use attribute access
    if hasattr(obj, key):
        return getattr(obj, key)

    raise KeyError(f"Key '{key}' not found in object")


class TensorDictSchemaBackend(BaseSchemaBackend):
    """Backend for TensorDict schema validation."""

    def preprocess(self, check_obj, inplace: bool = False):
        """Preprocesses a check object before applying check functions."""
        if not inplace:
            if _is_tensordict(check_obj):
                check_obj = check_obj.clone()
            else:
                check_obj = check_obj.copy()
        return check_obj

    def validate(
        self,
        check_obj,
        schema,
        *,
        head: int | None = None,
        tail: int | None = None,
        sample: int | None = None,
        random_state: int | None = None,
        lazy: bool = False,
        inplace: bool = False,
    ):
        """Validate a TensorDict against the schema."""
        error_handler = ErrorHandler(lazy)

        check_obj = self.preprocess(check_obj, inplace=inplace)

        if schema.coerce or any(
            tensor.coerce for tensor in schema.keys.values()
        ):
            check_obj = self.coerce_dtype(check_obj, schema=schema)

        error_handler = self.run_checks_and_handle_errors(
            error_handler, schema, check_obj, lazy
        )

        if error_handler.collected_errors:
            raise errors.SchemaErrors(
                schema=schema,
                schema_errors=error_handler.schema_errors,
                data=check_obj,
            )

        return check_obj

    def coerce_dtype(self, check_obj, schema=None):
        """Coerce the dtype of tensors in the TensorDict."""
        from pandera import errors
        from pandera.api.base.error_handler import ErrorHandler

        error_handler = ErrorHandler(lazy=True)

        def _set_tensor(obj, key, value):
            """Set tensor in TensorDict or tensorclass object."""
            try:
                from tensordict import TensorDictBase

                if isinstance(obj, TensorDictBase):
                    obj[key] = value
                else:
                    # For tensorclass, use attribute access
                    setattr(obj, key, value)
            except (KeyError, TypeError):
                pass

        for key, tensor_schema in schema.keys.items():
            # Apply coercion if either schema-level coerce is True or
            # tensor-level coerce is True, and dtype is specified
            if (
                not (schema.coerce or tensor_schema.coerce)
                or tensor_schema.dtype is None
            ):
                continue

            try:
                tensor = _get_tensor(check_obj, key)
                coerced_tensor = tensor_schema.dtype.try_coerce(tensor)
                _set_tensor(check_obj, key, coerced_tensor)
            except errors.SchemaError as err:
                error_handler.collect_error(
                    get_error_category(err.reason_code),
                    err.reason_code,
                    err,
                )
            except Exception as exc:
                from pandera.errors import SchemaError, SchemaErrors

                # Wrap non-SchemaError exceptions in SchemaError
                error = SchemaError(
                    schema=schema,
                    data=check_obj,
                    message=f"Coercion failed for key '{key}': {exc}",
                    reason_code=SchemaErrorReason.DATATYPE_COERCION,
                )
                error_handler.collect_error(
                    get_error_category(error.reason_code),
                    error.reason_code,
                    error,
                )

        if error_handler.collected_errors:
            raise errors.SchemaErrors(
                schema=schema,
                schema_errors=error_handler.schema_errors,
                data=check_obj,
            )

        return check_obj

    def run_checks_and_handle_errors(
        self, error_handler, schema, check_obj, lazy
    ):
        """Run all checks and collect errors."""
        self._check_batch_size(check_obj, schema, error_handler, lazy)
        self._check_keys(check_obj, schema, error_handler, lazy)
        self._check_dtypes_and_shapes(check_obj, schema, error_handler, lazy)
        self._run_value_checks(check_obj, schema, error_handler, lazy)

        return error_handler

    def _check_batch_size(self, check_obj, schema, error_handler, lazy):
        """Validate batch_size matches."""
        if schema.batch_size is None:
            return

        actual_batch_size = check_obj.batch_size
        expected_batch_size = schema.batch_size

        if len(actual_batch_size) != len(expected_batch_size):
            error_msg = (
                f"Expected batch_size {expected_batch_size}, "
                f"got {actual_batch_size}"
            )
            error = SchemaError(
                schema=schema,
                data=check_obj,
                message=error_msg,
                reason_code=SchemaErrorReason.WRONG_DATATYPE,
            )
            error_handler.collect_error(
                get_error_category(error.reason_code),
                error.reason_code,
                error,
            )
            return

        for i, (exp, act) in enumerate(
            zip(expected_batch_size, actual_batch_size)
        ):
            if exp is not None and exp != act:
                error_msg = f"Expected batch_size[{i}]={exp}, got batch_size[{i}]={act}"
                error = SchemaError(
                    schema=schema,
                    data=check_obj,
                    message=error_msg,
                    reason_code=SchemaErrorReason.WRONG_DATATYPE,
                )
                error_handler.collect_error(
                    get_error_category(error.reason_code),
                    error.reason_code,
                    error,
                )

    def _check_keys(self, check_obj, schema, error_handler, lazy):
        """Validate required keys exist.

        Keys may be plain strings (e.g. ``"observation"``) or nested tuples
        (e.g. ``("next", "observation")``) matching TorchRL's nested
        TensorDict layout. Nested membership is resolved through
        ``keys(include_nested=True)``.
        """
        try:
            from tensordict import TensorDictBase
        except ImportError:
            TensorDictBase = None

        is_td_base = TensorDictBase is not None and isinstance(
            check_obj, TensorDictBase
        )

        for key in schema.keys:
            try:
                if is_td_base:
                    # ``key in check_obj.keys()`` raises for tuple keys, so
                    # use the nested-aware key set when available.
                    if isinstance(key, tuple):
                        is_key_present = key in check_obj.keys(
                            include_nested=True
                        )
                    else:
                        is_key_present = key in check_obj.keys()
                else:
                    # For tensorclass, use keys() method or attribute access.
                    if hasattr(check_obj, "keys"):
                        is_key_present = key in check_obj.keys()
                    elif hasattr(check_obj, key):
                        is_key_present = True
                    else:
                        is_key_present = False
            except Exception:
                is_key_present = False

            if not is_key_present:
                error_msg = f"Missing key '{key}' in TensorDict"
                error = SchemaError(
                    schema=schema,
                    data=check_obj,
                    message=error_msg,
                    failure_cases={"failure_case": [key]},
                    reason_code=SchemaErrorReason.COLUMN_NOT_IN_DATAFRAME,
                    column_name=key,
                )
                error_handler.collect_error(
                    get_error_category(error.reason_code),
                    error.reason_code,
                    error,
                )

    def _check_dtypes_and_shapes(self, check_obj, schema, error_handler, lazy):
        """Validate tensor dtypes and shapes."""
        for key, tensor_schema in schema.keys.items():
            try:
                tensor = _get_tensor(check_obj, key)
            except KeyError:
                # Key doesn't exist (should already be caught by _check_keys)
                continue

            if not isinstance(tensor, torch.Tensor):
                error_msg = f"Key '{key}' is not a torch.Tensor"
                error = SchemaError(
                    schema=schema,
                    data=check_obj,
                    message=error_msg,
                    reason_code=SchemaErrorReason.WRONG_DATATYPE,
                )
                error_handler.collect_error(
                    get_error_category(error.reason_code),
                    error.reason_code,
                    error,
                )
                continue

            if tensor_schema.dtype is not None:
                expected_dtype = tensor_schema.dtype.type
                actual_dtype = tensor.dtype
                if actual_dtype != expected_dtype:
                    error_msg = (
                        f"Key '{key}': expected dtype {expected_dtype}, "
                        f"got {actual_dtype}"
                    )
                    error = SchemaError(
                        schema=schema,
                        data=check_obj,
                        message=error_msg,
                        reason_code=SchemaErrorReason.WRONG_DATATYPE,
                    )
                    error_handler.collect_error(
                        get_error_category(error.reason_code),
                        error.reason_code,
                        error,
                    )

            if tensor_schema.shape is not None:
                actual_shape = tuple(tensor.shape)
                expected_shape = tensor_schema.shape

                if len(actual_shape) != len(expected_shape):
                    error_msg = (
                        f"Key '{key}': expected shape {expected_shape}, "
                        f"got {actual_shape}"
                    )
                    error = SchemaError(
                        schema=schema,
                        data=check_obj,
                        message=error_msg,
                        reason_code=SchemaErrorReason.WRONG_DATATYPE,
                    )
                    error_handler.collect_error(
                        get_error_category(error.reason_code),
                        error.reason_code,
                        error,
                    )
                    continue

                for i, (exp, act) in enumerate(
                    zip(expected_shape, actual_shape)
                ):
                    if exp is not None and exp != act:
                        error_msg = (
                            f"Key '{key}': expected shape[{i}]={exp}, "
                            f"got shape[{i}]={act}"
                        )
                        error = SchemaError(
                            schema=schema,
                            data=check_obj,
                            message=error_msg,
                            reason_code=SchemaErrorReason.WRONG_DATATYPE,
                        )
                        error_handler.collect_error(
                            get_error_category(error.reason_code),
                            error.reason_code,
                            error,
                        )

    def _run_value_checks(self, check_obj, schema, error_handler, lazy):
        """Run value checks on tensor values."""
        from pandera.backends.tensordict.checks import (
            TensorDictCheckBackend,
        )

        for key, tensor_schema in schema.keys.items():
            try:
                tensor = _get_tensor(check_obj, key)
            except KeyError:
                continue

            if not tensor_schema.checks:
                continue

            for check_index, check in enumerate(tensor_schema.checks):
                # Use TensorDictCheckBackend directly.
                check_backend = TensorDictCheckBackend(check)
                try:
                    # Apply check to the tensor (not dict)
                    check_result = check_backend.apply(tensor)

                    # Postprocess result
                    check_result = check_backend.postprocess(
                        tensor, check_result
                    )
                except Exception as exc:
                    # A raised check function surfaces as a failure; normalize
                    # the ``CoreCheckResult`` (``passed``) to the ``CheckResult``
                    # contract (``check_passed``) consumed below, and carry the
                    # exception message for reporting.
                    check_result = CoreCheckResult(
                        passed=False,
                        check=check,
                        check_index=check_index,
                        check_output=None,
                        reason_code=SchemaErrorReason.CHECK_ERROR,
                        message=str(exc),
                    )

                check_passed = getattr(check_result, "check_passed", None)
                if check_passed is None:
                    check_passed = bool(getattr(check_result, "passed", False))
                if check_passed:
                    continue

                failure_cases = getattr(check_result, "failure_cases", None)
                check_error = getattr(check, "error", None)
                check_description = (
                    check_error() if callable(check_error) else check_error
                )
                if not check_description:
                    check_description = str(check)

                # If the check function raised, surface its exception message.
                exc_message = getattr(check_result, "message", None)
                if exc_message:
                    check_description = f"{check_description}: {exc_message}"

                try:
                    failure_detail = check_backend.failure_cases_message(
                        failure_cases
                    )
                except Exception:
                    failure_detail = "check failed"

                # Compose the message so it points at the failing elements.
                # e.g. "... greater_than(0.0): failure cases at index [1, 3]"
                if failure_detail != "check failed":
                    check_description = (
                        f"{check_description}: {failure_detail}"
                    )

                error_msg = (
                    f"column '{key}' failed element-wise validator number "
                    f"{check_index}: {check_description}"
                )
                error = SchemaError(
                    schema=schema,
                    data=check_obj,
                    message=error_msg,
                    failure_cases=failure_cases,
                    check=check,
                    check_index=check_index,
                    check_output=getattr(check_result, "check_output", None),
                    reason_code=SchemaErrorReason.CHECK_ERROR,
                    column_name=key,
                )
                error_handler.collect_error(
                    get_error_category(error.reason_code),
                    error.reason_code,
                    error,
                )

    def run_check(self, check_obj, schema, check, check_index, *args):
        """Run a single check on the check object."""
        raise NotImplementedError("Use _run_value_checks instead")

    def run_checks(self, check_obj, schema):
        """Run a list of checks on the check object."""
        raise NotImplementedError("Use _run_value_checks instead")

    def run_schema_component_checks(
        self, check_obj, schema, schema_components, lazy
    ):
        """Run checks for all schema components."""
        raise NotImplementedError("Use _run_value_checks instead")

    def check_name(self, check_obj, schema):
        """Core check that checks the name of the check object."""
        raise NotImplementedError

    def check_nullable(self, check_obj, schema):
        """Core check that checks the nullability of a check object."""
        raise NotImplementedError

    def check_unique(self, check_obj, schema):
        """Core check that checks the uniqueness of values in a check object."""
        raise NotImplementedError

    def check_dtype(self, check_obj, schema):
        """Core check that checks the data type of a check object."""
        raise NotImplementedError

    def failure_cases_metadata(
        self, schema_name: str, schema_errors: list[SchemaError]
    ):
        """Get failure cases metadata for lazy validation."""
        from collections import defaultdict

        from pandera.api.base.error_handler import ErrorHandler
        from pandera.errors import FailureCaseMetadata

        error_dicts = {}
        error_handler = ErrorHandler()
        error_handler.collect_errors(schema_errors)

        if error_handler.collected_errors:
            error_dicts = error_handler.summarize(schema_name=schema_name)
            error_dicts = dict(error_dicts)

        failure_cases = [
            err.failure_cases for err in schema_errors if err.failure_cases
        ]

        error_counts: dict[str, int] = defaultdict(int)
        for error in error_handler.collected_errors:
            error_counts[error["reason_code"].name] += 1

        return FailureCaseMetadata(
            failure_cases=failure_cases,
            message=error_dicts,
            error_counts=dict(error_counts),
        )

    def drop_invalid_rows(self, check_obj, error_handler):
        """Remove invalid elements in a check_obj."""
        raise NotImplementedError(
            "drop_invalid_rows is not applicable for TensorDict"
        )
