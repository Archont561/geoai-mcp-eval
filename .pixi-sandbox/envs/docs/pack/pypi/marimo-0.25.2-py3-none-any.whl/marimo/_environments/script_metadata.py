# Copyright 2026 Marimo. All rights reserved.
"""The PEP 723 inline script metadata block.

This module is the single reader and writer for the `# /// script` block in
marimo notebooks. In-place edits of a user's file delegate to the selected
environment manager so it owns the TOML edit and the user's formatting
survives; whole-block generation (converters, codegen, export) serializes
with tomlkit.

Markdown notebooks (.md/.qmd) carry the block in their frontmatter; edit
verbs round-trip the header verbatim through a carrier, a hidden sidecar
next to the notebook, so the manager anchors relative paths in the metadata
against the notebook's directory. The manager also runs from that directory,
so directory-scoped configuration applies.
"""

from __future__ import annotations

import asyncio
import contextlib
import errno
import hashlib
import os
import platform
import re
import stat
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from marimo import _loggers
from marimo._environments.errors import (
    EnvironmentManagerError,
    SandboxRestartRequired,
)
from marimo._environments.uv import (
    UvError,
    script_command_env,
    uv,
    uv_async,
    uv_stream,
)
from marimo._utils.toml import toml_reader
from marimo._utils.xdg import marimo_state_dir

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable, Iterator, Sequence

LOGGER = _loggers.marimo_logger()

REGEX = (
    r"(?m)^# /// (?P<type>[a-zA-Z0-9-]+)\r?$\n"
    r"(?P<content>(^#(?! ///\r?$)(| .*)\r?$\n)+)^# ///(?=\r?$)"
)


class ScriptMetadataError(EnvironmentManagerError):
    """A script metadata edit could not be completed."""


class ManifestConflictError(ScriptMetadataError):
    """The manifest changed after it was opened for editing."""


def _manifest_text(script: str) -> tuple[re.Match[str] | None, str]:
    matches = [
        match
        for match in re.finditer(REGEX, script)
        if match.group("type") == "script"
    ]
    if len(matches) > 1:
        raise ScriptMetadataError("Multiple script metadata blocks found")
    if not matches:
        return None, ""
    match = matches[0]
    contents = "".join(
        line[2:] if line.startswith("# ") else line[1:]
        for line in match.group("content").splitlines(keepends=True)
    )
    return match, contents.replace("\r\n", "\n")


def read_manifest(path: str) -> str:
    """Read the original TOML, including malformed TOML that needs repair."""
    if path.endswith((".md", ".qmd")):
        return _manifest_text(_read_frontmatter(path).header)[1]
    with open(path, encoding="utf-8", newline="") as file:
        return _manifest_text(file.read())[1]


def write_manifest(path: str, contents: str, *, previous: str) -> str:
    """Replace only metadata, rejecting stale edits and invalid TOML."""
    toml_reader.reads(contents)
    if any(line == "///" for line in contents.splitlines()):
        raise ScriptMetadataError("The manifest cannot contain script markers")
    with notebook_file_lock(path), materialized_for_edit(path) as target:
        file = Path(target.path)
        with file.open(encoding="utf-8", newline="") as source:
            script = source.read()
        match, current = _manifest_text(script)
        if current != previous:
            raise ManifestConflictError(
                "The manifest changed on disk. Reopen it before saving."
            )
        newline = "\r\n" if "\r\n" in script else "\n"
        block = wrap_block(contents.replace("\r\n", "\n")).replace(
            "\n", newline
        )
        if match is not None:
            updated = script[: match.start()] + block + script[match.end() :]
        elif script.startswith("#!"):
            shebang, _, rest = script.partition("\n")
            updated = f"{shebang}\n{block}{newline}{rest}"
        else:
            updated = f"{block}{newline}{script}"
        with file.open("w", encoding="utf-8", newline="") as destination:
            destination.write(updated)
    return read_manifest(path)


def loads(script: str) -> dict[str, Any] | None:
    """Parse the `# /// script` block, or None if the script has none.

    Adapted from https://peps.python.org/pep-0723/#reference-implementation
    """
    name = "script"
    matches = list(
        filter(lambda m: m.group("type") == name, re.finditer(REGEX, script))
    )
    if len(matches) > 1:
        raise ValueError(f"Multiple {name} blocks found")
    elif len(matches) == 1:
        content = "".join(
            line[2:] if line.startswith("# ") else line[1:]
            for line in matches[0].group("content").splitlines(keepends=True)
        )
        return toml_reader.reads(content)
    else:
        return None


def dumps(project: dict[str, Any]) -> str:
    """Serialize a project dict to a `# /// script` block."""
    import tomlkit

    return wrap_block(tomlkit.dumps(project))


def wrap_block(toml_content: str) -> str:
    """Wrap raw TOML content in `# /// script` markers."""
    result_lines = ["# /// script"]
    for line in toml_content.rstrip().split("\n"):
        result_lines.append(f"# {line}")
    result_lines.append("# ///")
    return "\n".join(result_lines)


def replace_block(script: str, block: str) -> str:
    """Replace the script's existing `# /// script` block with `block`."""
    # A callable replacement keeps backslashes in `block` literal.
    return re.sub(REGEX, lambda _: block, script, count=1)


def _metadata_block(path: str) -> str:
    with materialized_for_environment(path) as target:
        content = Path(target.path).read_text(encoding="utf-8")
        match = re.search(REGEX, content)
        return match.group(0) if match is not None else ""


@contextlib.contextmanager
def metadata_transaction(path: str) -> Iterator[None]:
    """Restore the previous manifest if a dependency mutation fails.

    Managers can save requirements before discovering they cannot solve them.
    Restore only metadata, preserving notebook code and other frontmatter
    edited while the manager was running. This does not undo partial changes
    to an environment made by the manager.
    """
    block = _metadata_block(path)
    try:
        yield
    except SandboxRestartRequired:
        # Keep the requested manifest so the restart can apply it.
        raise
    except (Exception, KeyboardInterrupt):
        if _metadata_block(path) == block:
            raise
        with materialized_for_edit(path) as target:
            file = Path(target.path)
            current = file.read_text(encoding="utf-8")
            restored = replace_block(current, block)
            if restored != current:
                file.write_text(restored, encoding="utf-8")
        raise


def copy_metadata(source: str, destination: str) -> None:
    """Copy one notebook's PEP 723 block into another notebook.

    This is a local Manifest operation: it does not invoke an environment
    manager or synchronize an Environment. It is used when an unnamed
    notebook's owned temporary Manifest becomes file-backed.
    """
    with materialized_for_environment(source) as source_target:
        with open(source_target.path, encoding="utf-8") as source_file:
            match = re.search(REGEX, source_file.read())
    if match is None:
        raise ScriptMetadataError(f"No script metadata found in {source}")
    block = match.group(0)

    with materialized_for_edit(destination) as destination_target:
        with open(destination_target.path, encoding="utf-8") as target_file:
            content = target_file.read()
        if loads(content) is not None:
            content = replace_block(content, block)
        elif content.startswith("#!"):
            shebang, _, rest = content.partition("\n")
            content = f"{shebang}\n{block}\n{rest}"
        else:
            content = f"{block}\n{content}"
        with open(
            destination_target.path, "w", encoding="utf-8"
        ) as target_file:
            target_file.write(content)


def ensure_metadata_block(path: str) -> None:
    """Create an empty dependency manifest when a notebook has none.

    The manifest module owns this structural write; environment managers
    only edit the materialized script it gives them.
    """
    if path.endswith((".md", ".qmd")):
        front = _read_frontmatter(path)
        if loads(front.header) is None:
            header = wrap_block("dependencies = []") + "\n" + front.header
            _write_frontmatter(path, front, header)
        return
    if not path.endswith(".py"):
        return
    with open(path, encoding="utf-8") as f:
        script = f.read()
    if loads(script) is not None:
        return

    block = wrap_block("dependencies = []") + "\n"
    if script.startswith("#!"):
        shebang, _, rest = script.partition("\n")
        script = shebang + "\n" + block + rest
    else:
        script = block + script
    with open(path, "w", encoding="utf-8") as f:
        f.write(script)


def with_python_version_requirement(project: dict[str, Any]) -> dict[str, Any]:
    # TODO(akshayka): consider locking the Python version for greater
    # reproducibility, instead of returning a lowerbound
    project = project.copy()
    version_tuple = platform.python_version_tuple()
    project["requires-python"] = f">={version_tuple[0]}.{version_tuple[1]}"
    return project


def add_dependencies(
    path: str,
    packages: Sequence[str],
    *,
    upgrade: bool = False,
    on_output: Callable[[str], None] | None = None,
) -> None:
    """Add packages to the script's metadata via `uv add --script`."""
    if not packages:
        return
    args = ["add", "--script"]

    def edit(target: str, cwd: str) -> None:
        command = [
            *args,
            target,
            *(["--upgrade"] if upgrade else []),
            *packages,
        ]
        if on_output is not None:
            uv_stream(command, on_output, env=script_command_env(), cwd=cwd)
        else:
            uv(["--quiet", *command], env=script_command_env(), cwd=cwd)

    _edit(path, edit)


def remove_dependencies(
    path: str,
    packages: Sequence[str],
    *,
    on_output: Callable[[str], None] | None = None,
) -> None:
    """Remove packages from the script's metadata via `uv remove --script`."""
    if not packages:
        return

    def edit(target: str, cwd: str) -> None:
        command = ["remove", "--script", target, *packages]
        if on_output is not None:
            uv_stream(command, on_output, env=script_command_env(), cwd=cwd)
        else:
            uv(["--quiet", *command], env=script_command_env(), cwd=cwd)

    _edit(path, edit)


def should_add_marimo(path: str) -> bool:
    """Whether `ensure_marimo` has work to do.

    False for non-`.py` targets and for missing or empty files, whose
    block is the notebook serializer's to create, and for manifests
    that already declare marimo.
    """
    if not path.endswith(".py"):
        return False
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return False

    from marimo._utils.inline_script_metadata import (
        has_marimo_in_script_metadata,
    )

    return has_marimo_in_script_metadata(path) is not True


def ensure_marimo(
    path: str,
    *,
    on_command: Callable[[Sequence[str]], None] | None = None,
) -> None:
    """Add marimo to the script metadata if it is not already a dependency.

    Creates the metadata block if the file has none. No-op for non-`.py`
    targets and for missing or empty files, whose block is the notebook
    serializer's to create.
    """
    if not should_add_marimo(path):
        return

    def edit(target: str, cwd: str) -> None:
        uv(
            ["add", "--script", target, "marimo"],
            env=script_command_env(),
            timeout=30,
            cwd=cwd,
            on_command=on_command,
        )

    _edit(path, edit)


async def ensure_marimo_async(
    path: str,
    *,
    on_command: Callable[[Sequence[str]], None] | None = None,
) -> None:
    if not should_add_marimo(path):
        return
    ensure_metadata_block(path)
    with materialized_for_edit(path) as target:
        await uv_async(
            ["add", "--script", target.path, "marimo"],
            env=script_command_env(),
            timeout=30,
            cwd=target.directory,
            on_command=on_command,
        )


def ensure_requires_python(path: str) -> None:
    """Add `requires-python` to existing script metadata if not present.

    Splices the line directly after the opening marker instead of
    re-serializing, to avoid reformatting the user's block. No-op if the
    file has no metadata block.
    """
    with open(path, encoding="utf-8") as f:
        content = f.read()

    project = loads(content)
    if project is None or "requires-python" in project:
        return

    version_tuple = platform.python_version_tuple()
    requires_line = (
        f'# requires-python = ">={version_tuple[0]}.{version_tuple[1]}"'
    )
    new_content = re.sub(
        r"^# /// script$",
        f"# /// script\n{requires_line}",
        content,
        count=1,
        flags=re.MULTILINE,
    )
    if new_content != content:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)


def _edit(path: str, edit: Callable[[str, str], None]) -> None:
    """Apply an edit and normalize expected operational failures.

    Edits receive the materialized script and the notebook's own directory,
    so manager-specific directory configuration is discovered.
    """
    try:
        with materialized_for_edit(path) as target:
            edit(target.path, target.directory)
    except (UvError, subprocess.TimeoutExpired, OSError) as error:
        raise ScriptMetadataError(
            f"Failed to update script metadata for {path}: {error}"
        ) from error


@dataclass(frozen=True)
class _Frontmatter:
    """A markdown notebook's frontmatter and its metadata block."""

    data: dict[str, Any]
    body: str
    # The comment-wrapped `# /// script` block.
    header: str
    # Whether the block came from the `pyproject` frontmatter key.
    is_pyproject: bool


def _read_frontmatter(path: str) -> _Frontmatter:
    from marimo._convert.markdown.to_ir import extract_frontmatter
    from marimo._utils import yaml
    from marimo._utils.inline_script_metadata import (
        get_headers_from_frontmatter,
    )

    with open(path, encoding="utf-8", newline="") as f:
        content = f.read()
    data, _ = extract_frontmatter(content)
    match = yaml.YAML_FRONT_MATTER_REGEX.match(content)
    # Preserve everything after the closing marker, including its newline.
    body = content[match.end(1) + len("---") :] if match else "\n" + content
    headers = get_headers_from_frontmatter(data)
    is_pyproject = bool(headers.get("pyproject", ""))
    header = (
        headers.get("pyproject", "")
        if is_pyproject
        else headers.get("header", "")
    )
    return _Frontmatter(
        data=data,
        body=body,
        header=header,
        is_pyproject=is_pyproject or not bool(header),
    )


_CARRIER_VERSION = 1


def _carrier_prefix(path: str) -> str:
    return f".marimo-v{_CARRIER_VERSION}-{os.path.basename(path)}"


@contextlib.contextmanager
def notebook_file_lock(path: str) -> Iterator[None]:
    """Serialize notebook read-modify-write operations across processes.

    Keep this separate from the carrier lock: async environment operations
    hold that lock while yielding, but notebook saves can run on the event loop.
    """
    with _file_lock(_notebook_lock_path(path), blocking=True):
        yield


def _notebook_lock_path(path: str) -> Path:
    # Processes may have different temporary directories for the same notebook.
    directory = marimo_state_dir() / "notebook-locks"
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    key = hashlib.sha256(
        os.path.normcase(os.path.realpath(path)).encode()
    ).hexdigest()
    return directory / f"{key}.lock"


@contextlib.contextmanager
def _stable_carrier_lock(
    path: str, *, blocking: bool = True
) -> Iterator[None]:
    # Carrier lifetimes can span async environment operations, so they must
    # use a different lock from notebook writes.
    target = _notebook_lock_path(path).with_suffix(".carrier.lock")
    with _file_lock(target, blocking=blocking):
        yield


@contextlib.contextmanager
def _file_lock(target: Path, *, blocking: bool) -> Iterator[None]:
    """Hold an OS lock on a persistent file.

    The lock file stays in place: unlinking it would let a new caller lock
    a different inode while existing callers still wait on the old one.
    Process exit releases the lock, including after a crash.
    """
    # Never truncate or follow a pre-existing link, even for the lock file.
    if target.is_symlink():
        raise OSError(f"Refusing to use symlink as lock file: {target}")
    descriptor = os.open(
        target, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600
    )
    with os.fdopen(descriptor, "r+b", buffering=0) as lock:
        if not stat.S_ISREG(os.fstat(lock.fileno()).st_mode):
            raise OSError(f"Lock file is not a regular file: {target}")
        if sys.platform == "win32":
            import msvcrt

            while True:
                try:
                    msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError as error:
                    if error.errno not in (errno.EACCES, errno.EDEADLK):
                        raise
                    if not blocking:
                        raise BlockingIOError from error
                    time.sleep(0.05)
            try:
                yield
            finally:
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(
                lock.fileno(),
                fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB),
            )
            try:
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


@contextlib.contextmanager
def _carrier(
    notebook: str, content: str, *, stable: bool = False
) -> Iterator[str]:
    """Materialize beside the notebook so uv preserves path semantics.

    Stable callers must hold `_stable_carrier_lock` for the full lifetime.
    Only that carrier can be reclaimed after a crash; age alone cannot
    distinguish another operation's active carrier from an abandoned one.
    """
    absolute = os.path.abspath(notebook)
    directory = os.path.dirname(absolute)
    try:
        if stable:
            target = os.path.join(directory, f"{_carrier_prefix(absolute)}.py")
            if os.path.islink(target):
                raise OSError(f"Refusing to replace carrier symlink: {target}")
            # The lock proves no cooperating process is still using it.
            with contextlib.suppress(FileNotFoundError):
                os.unlink(target)
            descriptor = os.open(
                target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600
            )
        else:
            descriptor, target = tempfile.mkstemp(
                dir=directory,
                prefix=f"{_carrier_prefix(absolute)}.",
                suffix=".py",
            )
    except OSError as error:
        raise ScriptMetadataError(
            f"Cannot create a metadata carrier beside {notebook}. "
            "Make the notebook directory writable and remove any "
            "conflicting carrier symlinks."
        ) from error
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as f:
            f.write(content)
        yield target
    finally:
        try:
            os.unlink(target)
        except OSError:
            LOGGER.debug("Could not remove carrier %s", target)


def _write_frontmatter(path: str, front: _Frontmatter, header: str) -> None:
    """Write a successfully edited carrier back to frontmatter."""
    from marimo._utils import yaml

    data = front.data
    if front.is_pyproject:
        # Strip '# ' and the leading/trailing /// markers
        header = "\n".join(
            [line[2:] for line in header.strip().splitlines()[1:-1]]
        )
        data["pyproject"] = header
    else:
        data["header"] = header

    header = yaml.marimo_compat_dump(data, sort_keys=False)
    document = f"---\n{header.strip()}\n---{front.body}"
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(document)


@dataclass(frozen=True)
class MaterializedScript:
    """A script an environment manager can operate on and its cwd."""

    path: str
    directory: str


@contextlib.contextmanager
def materialized_for_edit(path: str) -> Iterator[MaterializedScript]:
    """Materialize a notebook's manifest for one manager edit.

    Python notebooks are edited directly. Markdown and Quarto frontmatter
    use a unique carrier beside the notebook. A successful edit is written
    back after the manager returns; an exception leaves the notebook
    unchanged. The carrier is always removed by `_carrier`.
    """
    absolute = os.path.abspath(path)
    directory = os.path.dirname(absolute)
    if not path.endswith((".md", ".qmd")):
        yield MaterializedScript(path=absolute, directory=directory)
        return

    front = _read_frontmatter(absolute)
    with _carrier(absolute, front.header) as target:
        edit_succeeded = False
        try:
            yield MaterializedScript(path=target, directory=directory)
            edit_succeeded = True
        finally:
            # Only commit frontmatter after the caller's edit completed.
            # `_carrier` still removes the temporary script on every exit.
            if edit_succeeded:
                with open(target, encoding="utf-8") as f:
                    header = f.read()
                _write_frontmatter(absolute, front, header)


@contextlib.contextmanager
def materialized_for_environment(path: str) -> Iterator[MaterializedScript]:
    """Materializes a notebook's manifest for environment operations.

    A Python notebook is its own script, so its environment is the one
    `uv run notebook.py` uses and nothing is created. A markdown or
    Quarto notebook writes its header verbatim to the stable carrier
    `.marimo-v<N>-<name>.py` next to the notebook, deleted on exit. uv
    keys a script environment on the script's absolute path, so the
    stable name maps one notebook to one environment, reconciled in
    place across sessions. An OS lock serializes carrier lifetimes across
    threads and processes; its persistent file lives in marimo's state directory.
    """
    with _materialized_for_environment(path, blocking=True) as target:
        yield target


@contextlib.asynccontextmanager
async def materialized_for_environment_async(
    path: str,
) -> AsyncIterator[MaterializedScript]:
    """Wait cancellably for the same carrier lock used by synchronous callers."""
    with contextlib.ExitStack() as stack:
        while True:
            try:
                target = stack.enter_context(
                    _materialized_for_environment(path, blocking=False)
                )
                break
            except BlockingIOError:
                # OS file locks have no portable readiness notification.
                await asyncio.sleep(0.05)
        yield target


@contextlib.contextmanager
def _materialized_for_environment(
    path: str, *, blocking: bool
) -> Iterator[MaterializedScript]:
    absolute = os.path.abspath(path)
    directory = os.path.dirname(absolute)
    if not path.endswith((".md", ".qmd")):
        yield MaterializedScript(path=absolute, directory=directory)
        return

    with contextlib.ExitStack() as stack:
        try:
            stack.enter_context(
                _stable_carrier_lock(absolute, blocking=blocking)
            )
        except BlockingIOError:
            raise
        except OSError as error:
            raise ScriptMetadataError(
                f"Cannot lock a metadata carrier for {path}. "
                f"Check the lock directory's permissions and files: {error}"
            ) from error
        content = (
            "# Generated by marimo; safe to delete.\n"
            + _read_frontmatter(absolute).header
        )
        with _carrier(absolute, content, stable=True) as target:
            yield MaterializedScript(path=target, directory=directory)
